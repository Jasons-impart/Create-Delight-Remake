## A Squarful resourcepack addition for [Create Delight Remake](https://github.com/Jasons-impart/Create-Delight-Remake)


##  在完全适配CDR后会发行无create delight core的版本


###    [Squarful](https://modrinth.com/resourcepack/xekrsquarepattern)

---
### contributors
#### [普通的线框](https://xk-download.ovso.top/)

---
### 包含的模组   mods included
    Alex's caves
    bakeries
    create metallurgy
    create new age
    colorful hearts
    Jaden's nether expansion
    supplementaries
    tetra