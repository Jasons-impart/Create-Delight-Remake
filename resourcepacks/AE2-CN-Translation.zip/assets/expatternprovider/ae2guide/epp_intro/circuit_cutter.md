---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 电路板切片机
    icon: expatternprovider:circuit_cutter
categories:
- extended devices
item_ids:
- expatternprovider:circuit_cutter
---

# 电路板切片机

<Row gap="20">
<BlockImage id="expatternprovider:circuit_cutter" scale="8"></BlockImage>
</Row>

不能忍受缓慢的压印速度？现在我们有了电路板切片机！它可以直接将材料切割成电路板，所以大多数情况它比压印机快9倍。

**注意：没有接口的玻璃面不能连接到网络。**

