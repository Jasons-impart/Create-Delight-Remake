---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 量子桥
  icon: quantum_ring
---

# 量子网桥

见[量子网桥](../items-blocks-machines/quantum_bridge.md)。