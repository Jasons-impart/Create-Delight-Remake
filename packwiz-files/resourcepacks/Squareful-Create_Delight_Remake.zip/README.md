## A Squarful resourcepack addition for [Create Delight Remake](https://github.com/Jasons-impart/Create-Delight-Remake)


##  在完全适配CDR后会发行无create delight core的版本


###    [Squarful](https://modrinth.com/resourcepack/xekrsquarepattern)

---
### contributors
#### [普通的线框](https://xk-download.ovso.top/)

---
### 包含的模组   mods included
    Alex's caves
    bakeries
    create metallurgy
    create new age
    colorful hearts
    Jaden's nether expansion
    supplementaries
    tetra

## Squareful extension notice

This is a non-standalone extension pack for Squareful and requires the Squareful base pack to be installed.

The `assets/create/textures/gui/widgets.png` file is sourced from the official Squareful repository:

- Author: XeKr
- Source: https://github.com/XeKr/Squareful
- License: CC BY-NC-ND 4.0 with the Squareful Extension License
- License text: https://github.com/XeKr/Squareful/blob/main/EXTENSION_LICENSE
- Non-commercial use only
