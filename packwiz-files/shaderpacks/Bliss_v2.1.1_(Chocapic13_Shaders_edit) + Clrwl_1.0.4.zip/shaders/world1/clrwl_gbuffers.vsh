#version 120

#define END_SHADER

#define WORLD
#define ENTITIES
#define BLOCKENTITIES

#include "/dimensions/clrwl_solid.vsh"
