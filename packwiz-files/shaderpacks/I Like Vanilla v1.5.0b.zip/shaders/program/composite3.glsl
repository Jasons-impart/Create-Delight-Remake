in_out vec2 texcoord;



#ifdef FSH

#if REFLECTIONS_ENABLED == 1
	#include "/utils/depth.glsl"
	#include "/utils/projections.glsl"
	#include "/utils/getSkyColor.glsl"
	#include "/lib/reflections.glsl"
#endif
#if BORDER_FOG_ENABLED == 1
	#include "/utils/borderFogAmount.glsl"
#endif



void main() {
	/* DRAWBUFFERS:9 */
	gl_FragData[0] = vec4(0.0);
	
	
	
	ivec2 texelcoord = ivec2(texcoord * viewSize);
	
	// ======== REFLECTIONS ======== //
	
	#if REFLECTIONS_ENABLED == 1
		
		vec4 data;
		float depth0 = texelFetch(DEPTH_BUFFER_ALL, texelcoord, 0).r;
		float depth1 = texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord, 0).r;
		bool useTransparentData = depth0 < depth1; // if transparents depth is less than non-transparents depth then use transparents data tex
		#ifdef DISTANT_HORIZONS
			float dhDepth0 = texelFetch(DH_DEPTH_BUFFER_ALL, texelcoord, 0).r;
			float dhDepth1 = texelFetch(DH_DEPTH_BUFFER_WO_TRANS, texelcoord, 0).r;
			useTransparentData = useTransparentData || dhDepth0 < dhDepth1;
		#endif
		vec3 screenPos = vec3(texcoord, depth0);
		vec3 viewPos = screenToView(screenPos);
		#ifdef VOXY
			float vxDepth0 = texelFetch(VX_DEPTH_BUFFER_TRANS, texelcoord, 0).r;
			float vxDepth1 = texelFetch(VX_DEPTH_BUFFER_OPAQUE, texelcoord, 0).r;
			vec3 viewPosVx = screenToViewVx(vec3(texcoord, vxDepth0));
			useTransparentData = useTransparentData || (vxDepth0 < vxDepth1 && viewPosVx.z > viewPos.z - far / (16.0 / 2.0));
		#endif
		if (useTransparentData) {
			data = texelFetch(TRANSPARENT_DATA_TEXTURE, texelcoord, 0);
		} else {
			data = texelFetch(OPAQUE_DATA_TEXTURE, texelcoord, 0);
		}
		vec3 normal = decodeNormal(data.zw);
		#ifndef MODERN_BACKEND
			vec3 xDir = normalize(dFdx(viewPos));
			vec3 yDir = normalize(dFdy(viewPos));
			normal = cross(xDir, yDir);
		#endif
		vec2 lmcoord = unpack_2x8(data.x);
		
		#if REFLECTIVE_EVERYTHING == 1
			float reflectionStrength = 1.0;
		#else
			vec4 refSpecGlowingEntity = unpack_7_7_1_1(data.y);
			float reflectionStrength = refSpecGlowingEntity.x * (1.0 - refSpecGlowingEntity.z); // z holds whether or not it's glowing, x holds the reflectionStrength if not glowing
		#endif
		#if defined VOL_CLOUDS_ENABLED || NETHER_CLOUDS_ENABLED == 1 || END_CLOUDS_ENABLED == 1
			float invCloudsThickness = unpack_2x8(texelFetch(NOISY_RENDERS_TEXTURE, texelcoord, 0).g).x;
			reflectionStrength *= sqrt(invCloudsThickness);
		#endif
		#if BORDER_FOG_ENABLED == 1
			vec3 playerPos = mat3(gbufferModelViewInverse) * viewPos;
			float _fogDistance;
			float fogAmount = getBorderFogAmount(playerPos, _fogDistance);
			reflectionStrength *= 1.0 - fogAmount;
		#endif
		
		if (depthIsHand(depth0)) return;
		#ifdef DISTANT_HORIZONS
			if (depth0 == 1.0 && dhDepth0 == 1.0) return;
		#else
			if (depth0 == 1.0) return;
		#endif
		
		#ifdef DISTANT_HORIZONS
			if (depth0 == 1.0) viewPos = screenToViewDh(vec3(texcoord, dhDepth0));
		#endif
		
		if (reflectionStrength > 0.01) {
			gl_FragData[0] = getReflections(viewPos, normal, lmcoord, MAIN_TEXTURE, reflectionStrength);
		}
		
	#endif
	
}

#endif



#ifdef VSH

void main() {
	vec4 pos = ftransform();
	pos.xy *= REFLECTIONS_RENDER_SCALE;
	pos.xy -= 1.0 - REFLECTIONS_RENDER_SCALE;
	gl_Position = pos;
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
