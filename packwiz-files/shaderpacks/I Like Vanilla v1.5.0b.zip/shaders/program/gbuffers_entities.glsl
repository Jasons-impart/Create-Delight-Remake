in_out vec2 texcoord;
in_out vec2 lmcoord;
in_out vec4 glcolor;
in_out vec3 viewPos;
#if PBR_TYPE == 0
	flat in_out vec3 normal;
	flat in_out vec2 encodedNormal;
#elif PBR_TYPE == 1
	flat in_out mat3 tbn;
#endif



#ifdef FSH

#include "/lib/lighting/fsh_lighting.glsl"

void main() {
	
	vec4 color = texture2D(MAIN_TEXTURE, texcoord);
	color.rgb = color.rgb - (4.0 / 27.0) * color.rgb * color.rgb * color.rgb;
	color *= glcolor;
	
	float m = getLum(color.rgb);
	m = m * m * (3.0 - 2.0 * m);
	color.rgb *= 1.0 - TEXTURE_CONTRAST * 0.125 + m * TEXTURE_CONTRAST * 0.25;
	color.rgb = color.rgb * (1.0 + TEXTURE_CONTRAST_2 * 0.025) - TEXTURE_CONTRAST_2 * 0.025;
	
	
	// hurt flash, creeper flash, etc
	color.rgb = mix(color.rgb, entityColor.rgb, min(entityColor.a * 1.25, 1.0) * ENTITY_FLASH_STRENGTH);
	float glowing = step(0.01, entityColor.a);
	//color.rgb *= 1.0 + (1.0 - max(lmcoord.x, lmcoord.y)) * entityColor.a;
	
	
	#if PBR_TYPE == 0
		float reflectiveness = 0.0;
		float specularness = 0.3;
	#elif PBR_TYPE == 1
		vec2 pbrData = texture2D(specular, texcoord).rg;
		float reflectiveness = pbrData.g;
		if (int(reflectiveness * 255.0 + 0.5) > 229) reflectiveness -= 175.0 / 255.0;
		reflectiveness *= 0.5;
		float specularness = sqrt(pbrData.r);
		vec3 normal = texture2D(normals, texcoord).rgb;
		normal.xy -= 0.5;
		normal.xy *= PBR_NORMALS_AMOUNT * 0.75;
		normal.xy += 0.5;
		normal = normalize(normal * 2.0 - 1.0);
		normal = tbn * normal;
		vec2 encodedNormal = encodeNormal(normal);
	#endif
	
	
	// main lighting
	float isAfterDeferred = texelFetch(colortex10, ivec2(0), 0).r;
	if (isAfterDeferred > 0.5) {
		float _inSunlightAmount;
		doFshLighting(color.rgb, _inSunlightAmount, lmcoord.x, lmcoord.y, specularness, 0.0, viewPos, normal, gl_FragCoord.z);
	}
	
	
	float isEntity = step(0.95, color.a); // allow temporal filter is this entity is transparent
	
	reflectiveness = mix(reflectiveness, ENTITY_FLASH_GLOW_STRENGTH, glowing);
	
	//float dither = bayer64(gl_FragCoord.xy);
	//dither = fract(dither + 1.61803398875 * mod(float(frameCounter), 3600.0));
	//if (dither > color.a * 5.0) discard;
	//color.a = max(color.a, 0.2);
	
	
	/* DRAWBUFFERS:02 */
	#if DO_COLOR_CODED_GBUFFERS == 1
		color = vec4(0.5, 1.0, 0.0, 1.0);
	#endif
	color.rgb *= 0.5;
	gl_FragData[0] = vec4(color);
	gl_FragData[1] = vec4(
		pack_2x8(lmcoord),
		pack_7_7_1_1(reflectiveness, specularness, glowing, isEntity),
		encodedNormal
	);
	
}

#endif



#ifdef VSH

#include "/utils/projections.glsl"
#include "/lib/lighting/vsh_lighting.glsl"

#if TAA_ENABLED == 1
	#include "/lib/taa_jitter.glsl"
#endif

void main() {
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	adjustLmcoord(lmcoord);
	glcolor = gl_Color;
	
	#if SHADOWS_TYPE < 2
		// handle entity shadows
		if (glcolor.a < 1.0) {
			#ifdef NETHER
				// remove entity shadows, may cause other problems
				gl_Position = vec4(1.0);
				return;
			#else
				lmcoord.y = eyeBrightnessSmooth.y / 240.0;
			#endif
		}
	#endif
	
	#if PBR_TYPE != 0
		vec3 normal;
	#endif
	normal = gl_NormalMatrix * gl_Normal;
	#if PBR_TYPE == 0
		encodedNormal = encodeNormal(normal);
	#endif
	#if PBR_TYPE == 1
		vec3 tangent = normalize(gl_NormalMatrix * at_tangent.xyz);
		vec3 bitangent = normalize(cross(normal, tangent) * at_tangent.w);
		tbn = mat3(tangent, bitangent, normal);
	#endif
	
	viewPos = transform(gl_ModelViewMatrix, gl_Vertex.xyz);
	
	normal *= -sign(dot(normal, viewPos));
	
	
	gl_Position = viewToNdc(viewPos);
	
	
	#if TAA_ENABLED == 1
		#if TEMPORAL_FILTER_ENABLED == 1
			doTaaJitter(gl_Position.xy);
		#elif TEMPORAL_FILTER_ENABLED == 2
			// fixes jittery entity shadows
			if (gl_Color.a < 0.99) doTaaJitter(gl_Position.xy);
		#endif
	#endif
	gl_Position.z -= 0.0001;
	
	
	doVshLighting(lmcoord, glcolor.rgb, viewPos, normal, gl_Normal);
	
}

#endif
