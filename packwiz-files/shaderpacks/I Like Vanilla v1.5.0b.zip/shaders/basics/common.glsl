const float PI = 3.1415926538;
const float HALF_PI = PI / 2.0;

#ifdef FSH
	ivec2 texelcoord = ivec2(gl_FragCoord.xy);
#endif

#ifndef SHADER_VOXY
	uniform sampler2D texture;
	uniform sampler2D lightmap;
	uniform sampler2D normals;
	uniform sampler2D specular;
	uniform sampler2D tex;
	uniform sampler2D colortex1;
	uniform sampler2D colortex2;
	uniform sampler2D colortex3;
	uniform sampler2D colortex4;
	uniform sampler2D colortex5;
	uniform sampler2D colortex6;
	uniform sampler2D colortex7;
	uniform sampler2D colortex8;
	uniform sampler2D colortex9;
	uniform sampler2D colortex10;
	uniform sampler2D depthtex0;
	uniform sampler2D depthtex1;
	uniform sampler2D depthtex2;
	#if SHADOWS_TYPE == 2
		uniform sampler2D shadowtex0;
		#if COLORED_SHADOWS_ENABLED == 1
			uniform sampler2D shadowcolor0;
			uniform sampler2D shadowtex1;
		#endif
	#endif
	uniform sampler2D noisetex;
	#ifdef DISTANT_HORIZONS
		uniform sampler2D dhDepthTex0;
		uniform sampler2D dhDepthTex1;
	#endif
	#ifdef VOXY
		uniform sampler2D vxDepthTexOpaque;
		uniform sampler2D vxDepthTexTrans;
	#endif
#endif



// misc defines

#ifdef FSH
	#define in_out in
#else
	#define in_out out
#endif



// buffer values:

#define MAIN_TEXTURE                tex
#define PREV_TEXTURE                colortex1
#define OPAQUE_DATA_TEXTURE         colortex2
#define TRANSPARENT_DATA_TEXTURE    colortex3
#define BLOOM_TEXTURE               colortex4
#define SKY_OBJECTS_TEXTURE         colortex5
#define NOISY_RENDERS_TEXTURE       colortex6
#define PREV_DEPTH_TEXTURE          colortex7
#define WEATHER_TEXTURE             colortex8
#define VOXY_TRANSPARENTS_TEXTURE   colortex9
#define MISC_DATA_TEXTURE           colortex10

#define DEPTH_BUFFER_ALL                   depthtex0
#define DEPTH_BUFFER_WO_TRANS              depthtex1
#define DEPTH_BUFFER_WO_TRANS_OR_HANDHELD  depthtex2
#ifdef DISTANT_HORIZONS
	#define DH_DEPTH_BUFFER_ALL       dhDepthTex0
	#define DH_DEPTH_BUFFER_WO_TRANS  dhDepthTex1
#endif
#ifdef VOXY
	#define VX_DEPTH_BUFFER_OPAQUE  vxDepthTexOpaque
	#define VX_DEPTH_BUFFER_TRANS   vxDepthTexTrans
#endif





float pow2(float v) {
	return v * v;
}
float pow3(float v) {
	return v * v * v;
}
float pow4(float v) {
	float v2 = v * v;
	return v2 * v2;
}
float pow5(float v) {
	float v2 = v * v;
	return v2 * v2 * v;
}
float pow10(float v) {
	float v2 = v * v;
	float v4 = v2 * v2;
	return v4 * v4 * v2;
}

vec2 pow2(vec2 v) {
	return v * v;
}
vec2 pow3(vec2 v) {
	return v * v * v;
}

vec3 pow2(vec3 v) {
	return v * v;
}
vec3 pow3(vec3 v) {
	return v * v * v;
}

float getLum(vec3 color) {
	return dot(color, vec3(0.299, 0.587, 0.114));
}

float getSaturation(vec3 v) {
	float maxV = max(max(v.r, v.g), v.b);
	float minV = min(min(v.r, v.g), v.b);
	return (maxV == 0.0) ? 0.0 : (maxV - minV) / maxV;
}
float getSaturation2(vec3 c) {
    float maxc = max(c.r, max(c.g, c.b));
    float minc = min(c.r, min(c.g, c.b));
    float delta = maxc - minc;
    float l = (maxc + minc) * 0.5;

    if (delta == 0.0) return 0.0;
    return delta / (1.0 - abs(2.0 * l - 1.0));
}

// taken from: https://stackoverflow.com/a/17897228, which is licensed under WTFPL (public domain)
vec3 rgbToHsv(vec3 c) {
	vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
	vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
	vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
	float d = q.x - min(q.w, q.y);
	float e = 1.0e-10;
	return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsvToRgb(vec3 c) {
	vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
	vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
	return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

//vec3 smoothMin(vec3 v1, vec3 v2, float a) {
//	float v1Lum = getLum(v1);
//	float v2Lum = getLum(v2);
//	return (v1 + v2 - sqrt(pow2(v1 - v2) + a * (v1Lum + v2Lum) / 2.0)) / 2.0;
//}

vec3 smoothMax(vec3 v1, vec3 v2, float a) {
	float v1Lum = getLum(v1);
	float v2Lum = getLum(v2);
	return (v1 + v2 + sqrt(pow2(v1 - v2) + a * (v1Lum + v2Lum) / 2.0)) / 2.0;
}

// taken from https://iquilezles.org/articles/smin/:
float smoothMin(float a, float b, float k) {
    k *= 2.0;
    float x = b - a;
    return 0.5 * (a + b - sqrt(x * x + k * k));
}

float smoothMax(float a, float b, float k) {
    k *= 2.0;
    float x = a - b;
    return 0.5 * (a + b + sqrt(x * x + k * k));
}

float percentThrough(float v, float low, float high) {
	return clamp((v - low) / (high - low), 0.0, 1.0);
}

vec2 percentThrough(vec2 v, vec2 low, vec2 high) {
	return clamp((v - low) / (high - low), 0.0, 1.0);
}

vec3 percentThrough(vec3 v, vec3 low, vec3 high) {
	return clamp((v - low) / (high - low), 0.0, 1.0);
}

float cubicInterpolate(float edge0, float edge1, float edge2, float edge3, float value) {
	float value2 = value * value;
	float a0 = edge3 - edge2 - edge0 + edge1;
	float a1 = edge0 - edge1 - a0;
	float a2 = edge2 - edge0;
	float a3 = edge1;
	return(a0 * value * value2 + a1 * value2 + a2 * value + a3);
}

vec3 cubicInterpolate(vec3 edge0, vec3 edge1, vec3 edge2, vec3 edge3, float value) {
	float x = cubicInterpolate(edge0.x, edge1.x, edge2.x, edge3.x, value);
	float y = cubicInterpolate(edge0.y, edge1.y, edge2.y, edge3.y, value);
	float z = cubicInterpolate(edge0.z, edge1.z, edge2.z, edge3.z, value);
	return vec3(x, y, z);
}

// Thanks to Jessie (and Complementary) for dithering
float bayer2  (vec2 a) { a = 0.5 * floor(a); return fract(1.5 * fract(a.y) + a.x); }
float bayer4  (vec2 a) { return 0.25 * bayer2  (0.5 * a) + bayer2(a); }
float bayer8  (vec2 a) { return 0.25 * bayer4  (0.5 * a) + bayer2(a); }
float bayer16 (vec2 a) { return 0.25 * bayer8  (0.5 * a) + bayer2(a); }
float bayer32 (vec2 a) { return 0.25 * bayer16 (0.5 * a) + bayer2(a); }
float bayer64 (vec2 a) { return 0.25 * bayer32 (0.5 * a) + bayer2(a); }
float bayer128(vec2 a) { return 0.25 * bayer64 (0.5 * a) + bayer2(a); }
float bayer256(vec2 a) { return 0.25 * bayer128(0.5 * a) + bayer2(a); }

float pack_2x8(vec2 v) {
	return dot(floor(255.0 * v + 0.5), vec2(1.0 / 65535.0, 256.0 / 65535.0));
}
float pack_2x8(float x, float y) { return pack_2x8(vec2(x, y)); }

vec2 unpack_2x8(float pack) {
	vec2 v; v.x = modf((65535.0 / 256.0) * pack, v.y);
	return v * vec2(256.0 / 255.0, 1.0 / 255.0);
}

float pack_7_7_1_1(vec4 v) {
	uvec4 i = uvec4(v * vec4(127.0, 127.0, 1.0, 1.0) + 0.5);
	return (
		((i.x & 127u) << 0u) +
		((i.y & 127u) << 7u) +
		((i.z &   1u) << 14u) +
		((i.w &   1u) << 15u)
	) / 65535.0;
}
float pack_7_7_1_1(float x, float y, float z, float w) { return pack_7_7_1_1(vec4(x, y, z, w)); }
vec4 unpack_7_7_1_1(float pack) {
	uint v = uint(pack * 65535.0 + 0.5);
	return vec4(
		float((v >>  0u) & 127u) / 127.0,
		float((v >>  7u) & 127u) / 127.0,
		float((v >> 14u) &   1u) / 1.0,
		float((v >> 15u) &   1u) / 1.0
	);
}

// octahedral encoding/decoding
vec2 encodeNormal(vec3 v) {
	v /= abs(v.x) + abs(v.y) + abs(v.z);
	v.xy = (v.z >= 0.0) ? v.xy : (1.0 - abs(v.yx)) * (vec2(v.x >= 0.0, v.y >= 0.0) * 2.0 - 1.0);
	return v.xy * 0.5 + 0.5;
}

vec3 decodeNormal(vec2 v) {
	vec2 f = v * 2.0 - 1.0;
	vec3 n = vec3(f, 1.0 - abs(f.x) - abs(f.y));
	float t = max(-n.z, 0.0);
	n.xy += vec2(n.x >= 0.0 ? -t : t, n.y >= 0.0 ? -t : t);
	return normalize(n);
}



vec3 mult(mat4 a, vec3 b) {
	vec4 tmp = a * vec4(b, 1.0);
	return tmp.xyz / tmp.w;
}

vec3 transform(mat4 a, vec3 b) {
	return mat3(a) * b + a[3].xyz;
}

bool depthIsHand(float depth) {
	return depth < HAND_DEPTH;
}

void adjustLmcoord(inout vec2 lmcoord) {
	const float low = 1.0 / 16.0;
	const float high = 15.0 / 16.0;
	lmcoord = clamp((lmcoord - low) / (high - low), 0.0, 1.0);
}



void randomizeUint(inout uint rng) {
	#define ROTATE_RIGHT(value, shift) (value >> shift) | (value << (32u - shift))
	rng = rng * 747796405u + 2891336453u;
	rng ^= ROTATE_RIGHT(rng, 11u);
	rng ^= ROTATE_RIGHT(rng, 17u);
	rng ^= ROTATE_RIGHT(rng, 23u);
}

float randomFloat(inout uint rng) {
	randomizeUint(rng);
	const uint BIT_MASK = (2u << 16u) - 1u;
	float normalizedValue = float(rng & BIT_MASK) / float(BIT_MASK);
	return normalizedValue * 2.0 - 1.0;
}

vec2 randomVec2(inout uint rng) {
	float x = randomFloat(rng);
	float y = randomFloat(rng);
	return vec2(x, y);
}

vec3 randomVec3(inout uint rng) {
	float x = randomFloat(rng);
	float y = randomFloat(rng);
	float z = randomFloat(rng);
	return vec3(x, y, z);
}

vec3 randomVec3FromRValue(uint rng) {
	return randomVec3(rng);
}

float valueHash(ivec2 v) {
	vec2 h = fract(v * 0.3183099 + vec2(0.71, 0.113));
	h *= 17.0;
	return fract(h.x * h.y * (h.x + h.y));
}

float valueHash(ivec3 v) {
	vec3 h = fract(v * 0.3183099 + vec3(0.71, 0.113, 0.419));
	h *= 17.0;
	return fract(h.x * h.y * h.z * (h.x + h.y + h.z));
}

float valueHash(ivec4 v) {
    vec4 h = fract(v * 0.3183099 + vec4(0.71, 0.113, 0.419, 0.233));
    h *= 17.0;
    return fract(h.x * h.y * h.z * h.w * (h.x + h.y + h.z + h.w));
}

float valueNoise(vec3 v) {
	ivec3 i = ivec3(floor(v));
	vec3 f = v - i;
	
	float lll = valueHash(i);
	float llh = valueHash(i + ivec3(0, 0, 1));
	float lhl = valueHash(i + ivec3(0, 1, 0));
	float lhh = valueHash(i + ivec3(0, 1, 1));
	float hll = valueHash(i + ivec3(1, 0, 0));
	float hlh = valueHash(i + ivec3(1, 0, 1));
	float hhl = valueHash(i + ivec3(1, 1, 0));
	float hhh = valueHash(i + ivec3(1, 1, 1));
	
	vec3 u = f * f * (3.0 - 2.0 * f);
	float ll = mix(lll, llh, u.z);
	float lh = mix(lhl, lhh, u.z);
	float hl = mix(hll, hlh, u.z);
	float hh = mix(hhl, hhh, u.z);
	float l = mix(ll, lh, u.y);
	float h = mix(hl, hh, u.y);
	return mix(l, h, u.x);
}

float valueNoise(vec4 v) {
	ivec4 i = ivec4(floor(v));
	vec4 f = v - i;
	
	float llll = valueHash(i);
	float lllh = valueHash(i + ivec4(0, 0, 0, 1));
	float llhl = valueHash(i + ivec4(0, 0, 1, 0));
	float llhh = valueHash(i + ivec4(0, 0, 1, 1));
	float lhll = valueHash(i + ivec4(0, 1, 0, 0));
	float lhlh = valueHash(i + ivec4(0, 1, 0, 1));
	float lhhl = valueHash(i + ivec4(0, 1, 1, 0));
	float lhhh = valueHash(i + ivec4(0, 1, 1, 1));
	float hlll = valueHash(i + ivec4(1, 0, 0, 0));
	float hllh = valueHash(i + ivec4(1, 0, 0, 1));
	float hlhl = valueHash(i + ivec4(1, 0, 1, 0));
	float hlhh = valueHash(i + ivec4(1, 0, 1, 1));
	float hhll = valueHash(i + ivec4(1, 1, 0, 0));
	float hhlh = valueHash(i + ivec4(1, 1, 0, 1));
	float hhhl = valueHash(i + ivec4(1, 1, 1, 0));
	float hhhh = valueHash(i + ivec4(1, 1, 1, 1));
	
	vec4 u = f * f * (3.0 - 2.0 * f);
	float lll = mix(llll, lllh, u.w);
	float llh = mix(llhl, llhh, u.w);
	float lhl = mix(lhll, lhlh, u.w);
	float lhh = mix(lhhl, lhhh, u.w);
	float hll = mix(hlll, hllh, u.w);
	float hlh = mix(hlhl, hlhh, u.w);
	float hhl = mix(hhll, hhlh, u.w);
	float hhh = mix(hhhl, hhhh, u.w);
	float ll = mix(lll, llh, u.z);
	float lh = mix(lhl, lhh, u.z);
	float hl = mix(hll, hlh, u.z);
	float hh = mix(hhl, hhh, u.z);
	float l = mix(ll, lh, u.y);
	float h = mix(hl, hh, u.y);
	return mix(l, h, u.x);
}



float cubeLength(vec2 v) {
	return pow(abs(v.x * v.x * v.x) + abs(v.y * v.y * v.y), 1.0 / 3.0);
}

float getDistortFactor(vec3 v) {
	return (cubeLength(v.xy) + SHADOW_DISTORT_ADDITION) * 0.95;
}

vec3 distort(vec3 v, float distortFactor) {
	return vec3(v.xy / distortFactor, v.z * 0.5);
}

vec3 distort(vec3 v) {
	return distort(v, getDistortFactor(v));
}
