#version 140

#define SHADER_COMPOSITE5
#define END
#define FSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/composite5.glsl"
