#version 140

#define SHADER_COMPOSITE20
#define NETHER
#define FSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/composite20.glsl"
