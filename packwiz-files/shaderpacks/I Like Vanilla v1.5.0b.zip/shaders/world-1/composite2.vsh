#version 140

#define SHADER_COMPOSITE2
#define NETHER
#define VSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/composite2.glsl"
