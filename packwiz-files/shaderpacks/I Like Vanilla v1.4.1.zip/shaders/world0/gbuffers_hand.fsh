#version 140

#define SHADER_GBUFFERS_HAND
#define OVERWORLD
#define FSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/gbuffers_hand.glsl"
