#version 140

#define SHADER_DH_WATER
#define NETHER
#define VSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/dh_water.glsl"
